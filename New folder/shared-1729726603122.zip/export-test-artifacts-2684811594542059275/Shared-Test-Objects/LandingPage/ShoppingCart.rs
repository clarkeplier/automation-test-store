<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ShoppingCart</name>
   <tag></tag>
   <elementGuidId>6e2c00ce-fd70-4f98-8190-8c8ad6e2c39b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.dropdown.hover.open > a.dropdown-toggle</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='$ US Dollar'])[2]/following::a[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; 3 Items - $85.50&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>8c0fc9a6-d6f0-47ac-b884-744b30a8550f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://automationteststore.com/index.php?rt=checkout/cart</value>
      <webElementGuid>2bc0c576-5fab-4a64-9dbf-189205425375</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-toggle</value>
      <webElementGuid>a6395a67-5f7f-4c91-b787-e1696ce69c2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>  
			3
			Items			-
			$85.50
			
		</value>
      <webElementGuid>b64e512f-fb31-4fde-b508-bcf7a03abc0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;home&quot;]/div[@class=&quot;container-fixed&quot;]/header[1]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;col-md-12 headerdetails&quot;]/div[@class=&quot;block_7&quot;]/ul[@class=&quot;nav topcart pull-left&quot;]/li[@class=&quot;dropdown hover open&quot;]/a[@class=&quot;dropdown-toggle&quot;]</value>
      <webElementGuid>6f1e030d-86a5-42f7-bdd2-23a6d84442e6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$ US Dollar'])[2]/following::a[1]</value>
      <webElementGuid>2eb504b1-19fe-45c0-a4d7-33c5c9829c89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='£ Pound Sterling'])[1]/following::a[2]</value>
      <webElementGuid>0adbbaac-d376-42c4-b260-21acff752482</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Skinsheen Bronzer Stick'])[1]/preceding::a[2]</value>
      <webElementGuid>a244b8cd-a91d-41eb-b225-9b9d6471e05d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://automationteststore.com/index.php?rt=checkout/cart')])[2]</value>
      <webElementGuid>c70be01f-6baf-41f5-9f49-851a2c17b1a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/ul/li/a</value>
      <webElementGuid>a3f95df8-8423-41b3-8855-adc8837c408c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://automationteststore.com/index.php?rt=checkout/cart' and (text() = '  
			3
			Items			-
			$85.50
			
		' or . = '  
			3
			Items			-
			$85.50
			
		')]</value>
      <webElementGuid>fcc20750-0529-463a-92d4-3934eb362c1a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
