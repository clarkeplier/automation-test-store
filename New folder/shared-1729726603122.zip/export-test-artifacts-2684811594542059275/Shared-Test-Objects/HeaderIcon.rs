<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>HeaderIcon</name>
   <tag></tag>
   <elementGuidId>8e945fca-b8c0-4109-8722-120b436efb60</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//img[@alt='Automation Test Store']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>img[alt=&quot;Automation Test Store&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Automation Test Store&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>img</value>
      <webElementGuid>0f011076-ed0c-4c94-a645-f5f32760eac2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>src</name>
      <type>Main</type>
      <value>resources/image/18/7a/8.png</value>
      <webElementGuid>21de94eb-8518-4cd0-8846-96fa0e301afe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Automation Test Store</value>
      <webElementGuid>af920f58-c254-4cdb-a161-57acf61030e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>alt</name>
      <type>Main</type>
      <value>Automation Test Store</value>
      <webElementGuid>78215a2c-29af-44bc-b89f-e909921fd410</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;account-account&quot;]/div[@class=&quot;container-fixed&quot;]/header[1]/div[@class=&quot;headerstrip navbar navbar-inverse&quot;]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;navbar-header header-logo&quot;]/a[@class=&quot;logo&quot;]/img[1]</value>
      <webElementGuid>7d3c0fea-3949-4cf6-9f60-b02bcf57057e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:img</name>
      <type>Main</type>
      <value>//img[@alt='Automation Test Store']</value>
      <webElementGuid>cace6d0f-6c67-4faf-8f77-726698454aa8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//img</value>
      <webElementGuid>547a825b-c462-434f-8c6f-a25ca2e1f5cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//img[@src = 'resources/image/18/7a/8.png' and @title = 'Automation Test Store' and @alt = 'Automation Test Store']</value>
      <webElementGuid>87e00031-ec81-45b9-b990-525da870160c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
