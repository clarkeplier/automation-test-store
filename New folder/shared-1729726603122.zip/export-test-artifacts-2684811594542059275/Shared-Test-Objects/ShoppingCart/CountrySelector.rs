<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CountrySelector</name>
   <tag></tag>
   <elementGuidId>1a4034cc-c1b5-40dc-8b7b-be05d7fd30d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#estimate_country</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='estimate_country']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#estimate_country</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>0f81b76f-a8a0-43b0-9bd9-7b3fee93d5cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>country[]</value>
      <webElementGuid>dfcb1b00-fcb4-4ee3-a3b9-8db98eacdaf0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>estimate_country</value>
      <webElementGuid>f811dbce-538f-40fd-84d4-52d701b69340</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control </value>
      <webElementGuid>103bec21-6f6d-43ff-a52a-e7f737613295</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	            
			Afghanistan			
	            
			Albania			
	            
			Algeria			
	            
			American Samoa			
	            
			Andorra			
	            
			Angola			
	            
			Anguilla			
	            
			Antarctica			
	            
			Antigua and Barbuda			
	            
			Argentina			
	            
			Armenia			
	            
			Aruba			
	            
			Australia			
	            
			Austria			
	            
			Azerbaijan			
	            
			Bahamas			
	            
			Bahrain			
	            
			Bangladesh			
	            
			Barbados			
	            
			Belarus			
	            
			Belgium			
	            
			Belize			
	            
			Benin			
	            
			Bermuda			
	            
			Bhutan			
	            
			Bolivia			
	            
			Bosnia and Herzegowina			
	            
			Botswana			
	            
			Bouvet Island			
	            
			Brazil			
	            
			British Indian Ocean Territory			
	            
			Brunei Darussalam			
	            
			Bulgaria			
	            
			Burkina Faso			
	            
			Burundi			
	            
			Cambodia			
	            
			Cameroon			
	            
			Canada			
	            
			Cape Verde			
	            
			Cayman Islands			
	            
			Central African Republic			
	            
			Chad			
	            
			Chile			
	            
			China			
	            
			Christmas Island			
	            
			Cocos (Keeling) Islands			
	            
			Colombia			
	            
			Comoros			
	            
			Congo			
	            
			Cook Islands			
	            
			Costa Rica			
	            
			Cote D'Ivoire			
	            
			Croatia			
	            
			Cuba			
	            
			Cyprus			
	            
			Czech Republic			
	            
			Denmark			
	            
			Djibouti			
	            
			Dominica			
	            
			Dominican Republic			
	            
			East Timor			
	            
			Ecuador			
	            
			Egypt			
	            
			El Salvador			
	            
			Equatorial Guinea			
	            
			Eritrea			
	            
			Estonia			
	            
			Ethiopia			
	            
			Falkland Islands (Malvinas)			
	            
			Faroe Islands			
	            
			Fiji			
	            
			Finland			
	            
			France			
	            
			France, Metropolitan			
	            
			French Guiana			
	            
			French Polynesia			
	            
			French Southern Territories			
	            
			Gabon			
	            
			Gambia			
	            
			Georgia			
	            
			Germany			
	            
			Ghana			
	            
			Gibraltar			
	            
			Greece			
	            
			Greenland			
	            
			Grenada			
	            
			Guadeloupe			
	            
			Guam			
	            
			Guatemala			
	            
			Guinea			
	            
			Guinea-bissau			
	            
			Guyana			
	            
			Haiti			
	            
			Heard and Mc Donald Islands			
	            
			Honduras			
	            
			Hong Kong			
	            
			Hungary			
	            
			Iceland			
	            
			India			
	            
			Indonesia			
	            
			Iran (Islamic Republic of)			
	            
			Iraq			
	            
			Ireland			
	            
			Israel			
	            
			Italy			
	            
			Jamaica			
	            
			Japan			
	            
			Jordan			
	            
			Kazakhstan			
	            
			Kenya			
	            
			Kiribati			
	            
			Korea, Republic of			
	            
			Kuwait			
	            
			Kyrgyzstan			
	            
			Lao People's Democratic Republic			
	            
			Latvia			
	            
			Lebanon			
	            
			Lesotho			
	            
			Liberia			
	            
			Libyan Arab Jamahiriya			
	            
			Liechtenstein			
	            
			Lithuania			
	            
			Luxembourg			
	            
			Macau			
	            
			Macedonia			
	            
			Madagascar			
	            
			Malawi			
	            
			Malaysia			
	            
			Maldives			
	            
			Mali			
	            
			Malta			
	            
			Marshall Islands			
	            
			Martinique			
	            
			Mauritania			
	            
			Mauritius			
	            
			Mayotte			
	            
			Mexico			
	            
			Micronesia, Federated States of			
	            
			Moldova, Republic of			
	            
			Monaco			
	            
			Mongolia			
	            
			Montserrat			
	            
			Morocco			
	            
			Mozambique			
	            
			Myanmar			
	            
			Namibia			
	            
			Nauru			
	            
			Nepal			
	            
			Netherlands			
	            
			Netherlands Antilles			
	            
			New Caledonia			
	            
			New Zealand			
	            
			Nicaragua			
	            
			Niger			
	            
			Nigeria			
	            
			Niue			
	            
			Norfolk Island			
	            
			North Korea			
	            
			Northern Ireland			
	            
			Northern Mariana Islands			
	            
			Norway			
	            
			Oman			
	            
			Pakistan			
	            
			Palau			
	            
			Panama			
	            
			Papua New Guinea			
	            
			Paraguay			
	            
			Peru			
	            
			Philippines			
	            
			Pitcairn			
	            
			Poland			
	            
			Portugal			
	            
			Puerto Rico			
	            
			Qatar			
	            
			Reunion			
	            
			Romania			
	            
			Russia			
	            
			Rwanda			
	            
			Saint Kitts and Nevis			
	            
			Saint Lucia			
	            
			Saint Vincent and the Grenadines			
	            
			Samoa			
	            
			San Marino			
	            
			Sao Tome and Principe			
	            
			Saudi Arabia			
	            
			Senegal			
	            
			Seychelles			
	            
			Sierra Leone			
	            
			Singapore			
	            
			Slovak Republic			
	            
			Slovenia			
	            
			Solomon Islands			
	            
			Somalia			
	            
			South Africa			
	            
			South Georgia &amp; South Sandwich Islands			
	            
			Spain			
	            
			Sri Lanka			
	            
			St. Helena			
	            
			St. Pierre and Miquelon			
	            
			Sudan			
	            
			Suriname			
	            
			Svalbard and Jan Mayen Islands			
	            
			Swaziland			
	            
			Sweden			
	            
			Switzerland			
	            
			Syrian Arab Republic			
	            
			Taiwan			
	            
			Tajikistan			
	            
			Tanzania, United Republic of			
	            
			Thailand			
	            
			Togo			
	            
			Tokelau			
	            
			Tonga			
	            
			Trinidad and Tobago			
	            
			Tunisia			
	            
			Turkey			
	            
			Turkmenistan			
	            
			Turks and Caicos Islands			
	            
			Tuvalu			
	            
			Uganda			
	            
			Ukraine			
	            
			United Arab Emirates			
	            
			United Kingdom			
	            
			United States			
	            
			United States Minor Outlying Islands			
	            
			Uruguay			
	            
			Uzbekistan			
	            
			Vanuatu			
	            
			Vatican City State (Holy See)			
	            
			Venezuela			
	            
			Viet Nam			
	            
			Virgin Islands (British)			
	            
			Virgin Islands (U.S.)			
	            
			Wallis and Futuna Islands			
	            
			Western Sahara			
	            
			Yemen			
	            
			Yugoslavia			
	            
			Zaire			
	            
			Zambia			
	            
			Zimbabwe			
		</value>
      <webElementGuid>2a2f7fd1-2a84-4c0a-9b4a-6a0a03dbf8ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;estimate_country&quot;)</value>
      <webElementGuid>a99538ad-2105-482a-9d66-c206376b9ed8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='estimate_country']</value>
      <webElementGuid>fc1cc80a-3b0a-4cbb-bd03-73632405e91c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='estimate']/div/div/div/select</value>
      <webElementGuid>35384551-8026-47e5-b04b-de7450cbb47b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Country and State'])[1]/following::select[1]</value>
      <webElementGuid>40b5a0e9-6657-4737-8a20-4bd6c85d4b07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Estimate Shipping &amp; Taxes'])[1]/following::select[1]</value>
      <webElementGuid>9071023a-ca0a-4327-b80e-39f65b0a57d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ZIP/Post Code'])[1]/preceding::select[2]</value>
      <webElementGuid>dc51e552-8cc2-443b-8fa6-fece6d6e41be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div/div/div/select</value>
      <webElementGuid>96a25470-aeaf-4e23-a0b3-e0ee06c504e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'country[]' and @id = 'estimate_country' and (text() = concat(&quot;
	            
			Afghanistan			
	            
			Albania			
	            
			Algeria			
	            
			American Samoa			
	            
			Andorra			
	            
			Angola			
	            
			Anguilla			
	            
			Antarctica			
	            
			Antigua and Barbuda			
	            
			Argentina			
	            
			Armenia			
	            
			Aruba			
	            
			Australia			
	            
			Austria			
	            
			Azerbaijan			
	            
			Bahamas			
	            
			Bahrain			
	            
			Bangladesh			
	            
			Barbados			
	            
			Belarus			
	            
			Belgium			
	            
			Belize			
	            
			Benin			
	            
			Bermuda			
	            
			Bhutan			
	            
			Bolivia			
	            
			Bosnia and Herzegowina			
	            
			Botswana			
	            
			Bouvet Island			
	            
			Brazil			
	            
			British Indian Ocean Territory			
	            
			Brunei Darussalam			
	            
			Bulgaria			
	            
			Burkina Faso			
	            
			Burundi			
	            
			Cambodia			
	            
			Cameroon			
	            
			Canada			
	            
			Cape Verde			
	            
			Cayman Islands			
	            
			Central African Republic			
	            
			Chad			
	            
			Chile			
	            
			China			
	            
			Christmas Island			
	            
			Cocos (Keeling) Islands			
	            
			Colombia			
	            
			Comoros			
	            
			Congo			
	            
			Cook Islands			
	            
			Costa Rica			
	            
			Cote D&quot; , &quot;'&quot; , &quot;Ivoire			
	            
			Croatia			
	            
			Cuba			
	            
			Cyprus			
	            
			Czech Republic			
	            
			Denmark			
	            
			Djibouti			
	            
			Dominica			
	            
			Dominican Republic			
	            
			East Timor			
	            
			Ecuador			
	            
			Egypt			
	            
			El Salvador			
	            
			Equatorial Guinea			
	            
			Eritrea			
	            
			Estonia			
	            
			Ethiopia			
	            
			Falkland Islands (Malvinas)			
	            
			Faroe Islands			
	            
			Fiji			
	            
			Finland			
	            
			France			
	            
			France, Metropolitan			
	            
			French Guiana			
	            
			French Polynesia			
	            
			French Southern Territories			
	            
			Gabon			
	            
			Gambia			
	            
			Georgia			
	            
			Germany			
	            
			Ghana			
	            
			Gibraltar			
	            
			Greece			
	            
			Greenland			
	            
			Grenada			
	            
			Guadeloupe			
	            
			Guam			
	            
			Guatemala			
	            
			Guinea			
	            
			Guinea-bissau			
	            
			Guyana			
	            
			Haiti			
	            
			Heard and Mc Donald Islands			
	            
			Honduras			
	            
			Hong Kong			
	            
			Hungary			
	            
			Iceland			
	            
			India			
	            
			Indonesia			
	            
			Iran (Islamic Republic of)			
	            
			Iraq			
	            
			Ireland			
	            
			Israel			
	            
			Italy			
	            
			Jamaica			
	            
			Japan			
	            
			Jordan			
	            
			Kazakhstan			
	            
			Kenya			
	            
			Kiribati			
	            
			Korea, Republic of			
	            
			Kuwait			
	            
			Kyrgyzstan			
	            
			Lao People&quot; , &quot;'&quot; , &quot;s Democratic Republic			
	            
			Latvia			
	            
			Lebanon			
	            
			Lesotho			
	            
			Liberia			
	            
			Libyan Arab Jamahiriya			
	            
			Liechtenstein			
	            
			Lithuania			
	            
			Luxembourg			
	            
			Macau			
	            
			Macedonia			
	            
			Madagascar			
	            
			Malawi			
	            
			Malaysia			
	            
			Maldives			
	            
			Mali			
	            
			Malta			
	            
			Marshall Islands			
	            
			Martinique			
	            
			Mauritania			
	            
			Mauritius			
	            
			Mayotte			
	            
			Mexico			
	            
			Micronesia, Federated States of			
	            
			Moldova, Republic of			
	            
			Monaco			
	            
			Mongolia			
	            
			Montserrat			
	            
			Morocco			
	            
			Mozambique			
	            
			Myanmar			
	            
			Namibia			
	            
			Nauru			
	            
			Nepal			
	            
			Netherlands			
	            
			Netherlands Antilles			
	            
			New Caledonia			
	            
			New Zealand			
	            
			Nicaragua			
	            
			Niger			
	            
			Nigeria			
	            
			Niue			
	            
			Norfolk Island			
	            
			North Korea			
	            
			Northern Ireland			
	            
			Northern Mariana Islands			
	            
			Norway			
	            
			Oman			
	            
			Pakistan			
	            
			Palau			
	            
			Panama			
	            
			Papua New Guinea			
	            
			Paraguay			
	            
			Peru			
	            
			Philippines			
	            
			Pitcairn			
	            
			Poland			
	            
			Portugal			
	            
			Puerto Rico			
	            
			Qatar			
	            
			Reunion			
	            
			Romania			
	            
			Russia			
	            
			Rwanda			
	            
			Saint Kitts and Nevis			
	            
			Saint Lucia			
	            
			Saint Vincent and the Grenadines			
	            
			Samoa			
	            
			San Marino			
	            
			Sao Tome and Principe			
	            
			Saudi Arabia			
	            
			Senegal			
	            
			Seychelles			
	            
			Sierra Leone			
	            
			Singapore			
	            
			Slovak Republic			
	            
			Slovenia			
	            
			Solomon Islands			
	            
			Somalia			
	            
			South Africa			
	            
			South Georgia &amp; South Sandwich Islands			
	            
			Spain			
	            
			Sri Lanka			
	            
			St. Helena			
	            
			St. Pierre and Miquelon			
	            
			Sudan			
	            
			Suriname			
	            
			Svalbard and Jan Mayen Islands			
	            
			Swaziland			
	            
			Sweden			
	            
			Switzerland			
	            
			Syrian Arab Republic			
	            
			Taiwan			
	            
			Tajikistan			
	            
			Tanzania, United Republic of			
	            
			Thailand			
	            
			Togo			
	            
			Tokelau			
	            
			Tonga			
	            
			Trinidad and Tobago			
	            
			Tunisia			
	            
			Turkey			
	            
			Turkmenistan			
	            
			Turks and Caicos Islands			
	            
			Tuvalu			
	            
			Uganda			
	            
			Ukraine			
	            
			United Arab Emirates			
	            
			United Kingdom			
	            
			United States			
	            
			United States Minor Outlying Islands			
	            
			Uruguay			
	            
			Uzbekistan			
	            
			Vanuatu			
	            
			Vatican City State (Holy See)			
	            
			Venezuela			
	            
			Viet Nam			
	            
			Virgin Islands (British)			
	            
			Virgin Islands (U.S.)			
	            
			Wallis and Futuna Islands			
	            
			Western Sahara			
	            
			Yemen			
	            
			Yugoslavia			
	            
			Zaire			
	            
			Zambia			
	            
			Zimbabwe			
		&quot;) or . = concat(&quot;
	            
			Afghanistan			
	            
			Albania			
	            
			Algeria			
	            
			American Samoa			
	            
			Andorra			
	            
			Angola			
	            
			Anguilla			
	            
			Antarctica			
	            
			Antigua and Barbuda			
	            
			Argentina			
	            
			Armenia			
	            
			Aruba			
	            
			Australia			
	            
			Austria			
	            
			Azerbaijan			
	            
			Bahamas			
	            
			Bahrain			
	            
			Bangladesh			
	            
			Barbados			
	            
			Belarus			
	            
			Belgium			
	            
			Belize			
	            
			Benin			
	            
			Bermuda			
	            
			Bhutan			
	            
			Bolivia			
	            
			Bosnia and Herzegowina			
	            
			Botswana			
	            
			Bouvet Island			
	            
			Brazil			
	            
			British Indian Ocean Territory			
	            
			Brunei Darussalam			
	            
			Bulgaria			
	            
			Burkina Faso			
	            
			Burundi			
	            
			Cambodia			
	            
			Cameroon			
	            
			Canada			
	            
			Cape Verde			
	            
			Cayman Islands			
	            
			Central African Republic			
	            
			Chad			
	            
			Chile			
	            
			China			
	            
			Christmas Island			
	            
			Cocos (Keeling) Islands			
	            
			Colombia			
	            
			Comoros			
	            
			Congo			
	            
			Cook Islands			
	            
			Costa Rica			
	            
			Cote D&quot; , &quot;'&quot; , &quot;Ivoire			
	            
			Croatia			
	            
			Cuba			
	            
			Cyprus			
	            
			Czech Republic			
	            
			Denmark			
	            
			Djibouti			
	            
			Dominica			
	            
			Dominican Republic			
	            
			East Timor			
	            
			Ecuador			
	            
			Egypt			
	            
			El Salvador			
	            
			Equatorial Guinea			
	            
			Eritrea			
	            
			Estonia			
	            
			Ethiopia			
	            
			Falkland Islands (Malvinas)			
	            
			Faroe Islands			
	            
			Fiji			
	            
			Finland			
	            
			France			
	            
			France, Metropolitan			
	            
			French Guiana			
	            
			French Polynesia			
	            
			French Southern Territories			
	            
			Gabon			
	            
			Gambia			
	            
			Georgia			
	            
			Germany			
	            
			Ghana			
	            
			Gibraltar			
	            
			Greece			
	            
			Greenland			
	            
			Grenada			
	            
			Guadeloupe			
	            
			Guam			
	            
			Guatemala			
	            
			Guinea			
	            
			Guinea-bissau			
	            
			Guyana			
	            
			Haiti			
	            
			Heard and Mc Donald Islands			
	            
			Honduras			
	            
			Hong Kong			
	            
			Hungary			
	            
			Iceland			
	            
			India			
	            
			Indonesia			
	            
			Iran (Islamic Republic of)			
	            
			Iraq			
	            
			Ireland			
	            
			Israel			
	            
			Italy			
	            
			Jamaica			
	            
			Japan			
	            
			Jordan			
	            
			Kazakhstan			
	            
			Kenya			
	            
			Kiribati			
	            
			Korea, Republic of			
	            
			Kuwait			
	            
			Kyrgyzstan			
	            
			Lao People&quot; , &quot;'&quot; , &quot;s Democratic Republic			
	            
			Latvia			
	            
			Lebanon			
	            
			Lesotho			
	            
			Liberia			
	            
			Libyan Arab Jamahiriya			
	            
			Liechtenstein			
	            
			Lithuania			
	            
			Luxembourg			
	            
			Macau			
	            
			Macedonia			
	            
			Madagascar			
	            
			Malawi			
	            
			Malaysia			
	            
			Maldives			
	            
			Mali			
	            
			Malta			
	            
			Marshall Islands			
	            
			Martinique			
	            
			Mauritania			
	            
			Mauritius			
	            
			Mayotte			
	            
			Mexico			
	            
			Micronesia, Federated States of			
	            
			Moldova, Republic of			
	            
			Monaco			
	            
			Mongolia			
	            
			Montserrat			
	            
			Morocco			
	            
			Mozambique			
	            
			Myanmar			
	            
			Namibia			
	            
			Nauru			
	            
			Nepal			
	            
			Netherlands			
	            
			Netherlands Antilles			
	            
			New Caledonia			
	            
			New Zealand			
	            
			Nicaragua			
	            
			Niger			
	            
			Nigeria			
	            
			Niue			
	            
			Norfolk Island			
	            
			North Korea			
	            
			Northern Ireland			
	            
			Northern Mariana Islands			
	            
			Norway			
	            
			Oman			
	            
			Pakistan			
	            
			Palau			
	            
			Panama			
	            
			Papua New Guinea			
	            
			Paraguay			
	            
			Peru			
	            
			Philippines			
	            
			Pitcairn			
	            
			Poland			
	            
			Portugal			
	            
			Puerto Rico			
	            
			Qatar			
	            
			Reunion			
	            
			Romania			
	            
			Russia			
	            
			Rwanda			
	            
			Saint Kitts and Nevis			
	            
			Saint Lucia			
	            
			Saint Vincent and the Grenadines			
	            
			Samoa			
	            
			San Marino			
	            
			Sao Tome and Principe			
	            
			Saudi Arabia			
	            
			Senegal			
	            
			Seychelles			
	            
			Sierra Leone			
	            
			Singapore			
	            
			Slovak Republic			
	            
			Slovenia			
	            
			Solomon Islands			
	            
			Somalia			
	            
			South Africa			
	            
			South Georgia &amp; South Sandwich Islands			
	            
			Spain			
	            
			Sri Lanka			
	            
			St. Helena			
	            
			St. Pierre and Miquelon			
	            
			Sudan			
	            
			Suriname			
	            
			Svalbard and Jan Mayen Islands			
	            
			Swaziland			
	            
			Sweden			
	            
			Switzerland			
	            
			Syrian Arab Republic			
	            
			Taiwan			
	            
			Tajikistan			
	            
			Tanzania, United Republic of			
	            
			Thailand			
	            
			Togo			
	            
			Tokelau			
	            
			Tonga			
	            
			Trinidad and Tobago			
	            
			Tunisia			
	            
			Turkey			
	            
			Turkmenistan			
	            
			Turks and Caicos Islands			
	            
			Tuvalu			
	            
			Uganda			
	            
			Ukraine			
	            
			United Arab Emirates			
	            
			United Kingdom			
	            
			United States			
	            
			United States Minor Outlying Islands			
	            
			Uruguay			
	            
			Uzbekistan			
	            
			Vanuatu			
	            
			Vatican City State (Holy See)			
	            
			Venezuela			
	            
			Viet Nam			
	            
			Virgin Islands (British)			
	            
			Virgin Islands (U.S.)			
	            
			Wallis and Futuna Islands			
	            
			Western Sahara			
	            
			Yemen			
	            
			Yugoslavia			
	            
			Zaire			
	            
			Zambia			
	            
			Zimbabwe			
		&quot;))]</value>
      <webElementGuid>0377fd3a-b24c-43a6-98ce-d7d48fcb49fb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
