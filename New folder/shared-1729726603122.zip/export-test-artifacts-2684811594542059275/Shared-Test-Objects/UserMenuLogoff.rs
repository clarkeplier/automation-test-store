<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>UserMenuLogoff</name>
   <tag></tag>
   <elementGuidId>1324b29d-dcd3-4261-9154-bb48f2989838</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='customer_menu_top']/li/ul/li[10]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Not Jane? Logoff&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f5e7f7e7-69de-4587-b46a-784592c5c6af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://automationteststore.com/index.php?rt=account/logout</value>
      <webElementGuid>ffcc5359-8d8b-4fd3-8e0b-a6164ab8c2c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 
			  	Not Jane? Logoff</value>
      <webElementGuid>df25b9ae-2a71-4b19-b3a9-5661ed270f07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;customer_menu_top&quot;)/li[@class=&quot;dropdown&quot;]/ul[@class=&quot;sub_menu dropdown-menu&quot;]/li[@class=&quot;dropdown&quot;]/a[1]</value>
      <webElementGuid>feed4d00-d3b5-44be-bcb4-a93fb20cb244</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='customer_menu_top']/li/ul/li[10]/a</value>
      <webElementGuid>b1f22864-ba28-4255-9269-5e92651dbd5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Not Jane? Logoff')]</value>
      <webElementGuid>a155a7b9-39ea-4a97-ba46-aa09b80e2ba2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Main Menu'])[1]/preceding::a[1]</value>
      <webElementGuid>973e13bb-9dbe-4d07-98c5-2e4a5b8e6146</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Specials'])[1]/preceding::a[1]</value>
      <webElementGuid>d1463d64-de03-43ed-9c4c-5203d5cca223</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://automationteststore.com/index.php?rt=account/logout')]</value>
      <webElementGuid>dc5da73b-87b3-41a0-914d-2a0013a702d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/a</value>
      <webElementGuid>4882a58c-f004-478f-9d14-df2ccbd326e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://automationteststore.com/index.php?rt=account/logout' and (text() = ' 
			  	Not Jane? Logoff' or . = ' 
			  	Not Jane? Logoff')]</value>
      <webElementGuid>780db5f4-eb54-4281-ae4f-a336f6dee951</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
