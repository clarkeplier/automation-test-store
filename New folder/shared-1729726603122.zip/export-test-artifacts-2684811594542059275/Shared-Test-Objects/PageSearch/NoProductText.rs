<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>NoProductText</name>
   <tag></tag>
   <elementGuidId>ca91c209-d736-4d41-885c-9852a4012c76</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='maincontainer']/div/div/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.contentpanel > div:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;There is no product that matches the search criteria.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>046f63c9-4289-4539-ac6a-65c0e1fff4a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			There is no product that matches the search criteria.		</value>
      <webElementGuid>d5615761-2dc1-4024-8d7e-d1c2529ff947</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;maincontainer&quot;)/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;col-md-12 col-xs-12 mt20&quot;]/div[1]/div[@class=&quot;contentpanel&quot;]/div[2]</value>
      <webElementGuid>86b174e0-025c-47f9-9e6b-61879511a5c8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='maincontainer']/div/div/div/div/div[2]</value>
      <webElementGuid>83fe37d5-801c-44a9-9661-a0c52a1933bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Products meeting the search criteria'])[1]/following::div[1]</value>
      <webElementGuid>361bc053-daab-488c-a343-3fe0feca6278</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/preceding::div[3]</value>
      <webElementGuid>00c7d951-b2dd-41df-8377-ad74aed07473</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Us'])[1]/preceding::div[6]</value>
      <webElementGuid>44f72162-6053-4790-b535-aed31eea00ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='There is no product that matches the search criteria.']/parent::*</value>
      <webElementGuid>e2b8e448-1cd5-4bcd-a591-1fb7aa38ff50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div[2]</value>
      <webElementGuid>0fff3fef-9f23-43f7-9c45-e21c3f472f35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '&#xd;
			There is no product that matches the search criteria.		' or . = '&#xd;
			There is no product that matches the search criteria.		')]</value>
      <webElementGuid>ae23e2cb-47c8-48f3-ba29-611c9ccb6c4b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
