<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Add to Cart</name>
   <tag></tag>
   <elementGuidId>9da81a82-53fd-42a6-9463-f32326c2764c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@onclick=&quot;$(this).closest('form').submit(); return false;&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.cart</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Add to Cart&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a67b81cd-9cff-4813-96a1-0ef75e62c336</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#</value>
      <webElementGuid>05be4b46-4c44-427c-b55a-9450a79257fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>$(this).closest('form').submit(); return false;</value>
      <webElementGuid>55eaca1a-4cfe-4f73-a429-563be9e91121</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>cart</value>
      <webElementGuid>1fc78ea2-fede-4a26-99f9-5735f926fe7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
													
													Add to Cart												</value>
      <webElementGuid>a5051c5c-ebb9-4e3c-8d75-029f1fa97472</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;product&quot;)/fieldset[1]/div[@class=&quot;mt20&quot;]/ul[@class=&quot;productpagecart&quot;]/li[1]/a[@class=&quot;cart&quot;]</value>
      <webElementGuid>e694ca66-b810-41b6-b907-66247acf5992</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@onclick=&quot;$(this).closest('form').submit(); return false;&quot;]</value>
      <webElementGuid>5f749030-a5d6-4551-9e0d-4dd14534de52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='product']/fieldset/div[4]/ul/li/a</value>
      <webElementGuid>26ed4123-64a6-42b5-8216-6c06c363f349</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$38.00'])[3]/following::a[1]</value>
      <webElementGuid>e445c798-85c7-4bdf-b680-c1d501da62b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Description'])[1]/preceding::a[2]</value>
      <webElementGuid>aef3ebc6-f6c8-4b74-b1a8-aca0c6914ecc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add to Cart']/parent::*</value>
      <webElementGuid>bf7109da-80a7-436b-8652-787383112418</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#')]</value>
      <webElementGuid>a3b71bff-53a7-474d-8cbb-17d2cca62e16</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/ul/li/a</value>
      <webElementGuid>d8135561-69c3-4589-94be-5fa4e5acb3c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#' and (text() = '
													
													Add to Cart												' or . = '
													
													Add to Cart												')]</value>
      <webElementGuid>01bf9318-131f-436b-bd2b-018a3b27d28f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
