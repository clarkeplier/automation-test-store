<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ContinueButton</name>
   <tag></tag>
   <elementGuidId>555a12f1-78a5-4f7a-a575-62cda45e7f23</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn.btn-orange.pull-right.lock-on-click</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='submit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot; Continue&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>ac9c3fba-d0c3-4d98-a68b-75336d089456</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-orange pull-right lock-on-click</value>
      <webElementGuid>1e1553b7-f1b2-420b-8b01-05f2b78f91b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Continue</value>
      <webElementGuid>53290d57-ea7f-4a1e-8edd-5ec6e60e6404</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>submit</value>
      <webElementGuid>e20b7d7b-0ad6-4f4a-9077-8daf4e668e0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-loading-text</name>
      <type>Main</type>
      <value>&lt;i class='fa fa-refresh fa-spin'>&lt;/i></value>
      <webElementGuid>fd9eb2a4-8f66-44fc-bfdf-85c61c8ca8dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	    	    
	    	    Continue	    	</value>
      <webElementGuid>46f82c2f-dba8-40bd-be5e-1cbaa92a8804</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;guestFrm&quot;)/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-md-12 mt20&quot;]/button[@class=&quot;btn btn-orange pull-right lock-on-click&quot;]</value>
      <webElementGuid>0d195cc4-17df-4d3d-bd98-a029c5bb3cb7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@type='submit']</value>
      <webElementGuid>0379587d-5815-4050-9cfa-41fdda36bf63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='guestFrm']/div[4]/div/button</value>
      <webElementGuid>6e9e7b6f-68e1-4df8-9f81-dc6229755279</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[15]/following::button[1]</value>
      <webElementGuid>3abe1e2e-be8b-46f8-9b5e-33fdfc1bca61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Country:'])[2]/following::button[1]</value>
      <webElementGuid>a0341c45-64a6-4ea3-9300-8f8a952c0e69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Summary'])[1]/preceding::button[1]</value>
      <webElementGuid>a3bce995-4ff6-44fa-8d4f-6210fc81e2f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Continue']/parent::*</value>
      <webElementGuid>05e5b852-5a11-47c3-86f8-bc9950f5bb06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/button</value>
      <webElementGuid>97044bc1-955b-494b-94f6-43d0af837f33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@title = 'Continue' and @type = 'submit' and (text() = '
	    	    
	    	    Continue	    	' or . = '
	    	    
	    	    Continue	    	')]</value>
      <webElementGuid>79b0f474-6c89-4bd2-8339-18d3403ce448</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
