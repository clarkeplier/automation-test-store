<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Your Order Has Been Processed</name>
   <tag></tag>
   <elementGuidId>4a5b09ff-8e47-4699-a9bc-43e121000730</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.heading1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='maincontainer']/div/div/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot; Your Order Has Been Processed!&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>cd65e97f-07dc-490a-88be-4c8e1c11b360</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>heading1</value>
      <webElementGuid>5d76f9db-e18d-4f14-9b99-c488fdc4c1ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
   Your Order Has Been Processed!
  
</value>
      <webElementGuid>4202675b-6928-4201-b120-00c0ac266e1f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;maincontainer&quot;)/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;col-md-12 col-xs-12 mt20&quot;]/div[1]/h1[@class=&quot;heading1&quot;]</value>
      <webElementGuid>aae91673-9d93-44b0-9f9e-e5012e2b7eec</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='maincontainer']/div/div/div/h1</value>
      <webElementGuid>3a2737bf-b435-4c5d-897f-b679767bac4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Success'])[1]/following::h1[1]</value>
      <webElementGuid>9dceee9a-d04c-46ed-a36e-9004622f52ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirm'])[1]/following::h1[1]</value>
      <webElementGuid>c1569972-82d8-4d10-82e0-9f4a8cf3b782</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='invoice page'])[1]/preceding::h1[1]</value>
      <webElementGuid>b47e102a-7d52-49bf-ac6d-921fa31efc33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>9ad67a95-17c7-4415-b69a-74080d6e95d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = '
   Your Order Has Been Processed!
  
' or . = '
   Your Order Has Been Processed!
  
')]</value>
      <webElementGuid>c7fe99eb-5087-4708-90d7-10393f76eff4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
